<template>
  <div class="p-6 max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold text-center text-gray-900 mb-6">About Taskurai</h1>
    <div class="h-full flex items-center justify-center mb-6">
      <img 
        src="@/assets/home_icon_7.png" 
        alt="Home" 
        class="h-20 w-20 object-contain rounded-full"
      >
    </div>
    <p class="text-lg text-center text-gray-700">
      Welcome to Taskurai, a productivity tool that helps you master your tasks with focus and discipline!
    </p>
    <div class="mt-8">
      <h2 class="text-2xl font-semibold text-gray-800">What does "Taskurai" mean?</h2>
      <p class="mt-4 text-base text-gray-600">
        The name <strong>"Taskurai"</strong> is a creative blend of the word <strong>"task"</strong> and the Japanese
        suffix <strong>"-urai"</strong>, inspired by <strong>"samurai"</strong>.
      </p>
      <p class="mt-2 text-base text-gray-600">
        - <strong>"Task"</strong> refers to the things you need to accomplish, your to-dos, and tasks at hand.
      </p>
      <p class="mt-2 text-base text-gray-600">
        - <strong>"-urai"</strong> is inspired by <strong>"samurai"</strong>, the disciplined warriors of Japanese history.
        The suffix evokes a sense of strength, dedication, and professionalism.
      </p>
      <p class="mt-4 text-lg text-gray-700">
        So, "Taskurai" symbolizes a focus on mastering your tasks with precision and commitment—just like a samurai
        approaching their duty.
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "AboutUs",
};
</script>
